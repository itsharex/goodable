# PIL.ImageGrab mock
def grab(*args, **kwargs):
    raise NotImplementedError("PIL ImageGrab.grab not implemented in mock")
